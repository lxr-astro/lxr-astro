# Firefox Alpenglow Dark for Chrome

This is a Chrome/Chromium/Edge theme-only port of the dark visual style from Firefox Alpenglow. It contains only a Manifest V3 theme manifest and generated PNG assets. It intentionally does not include background scripts, content scripts, popup UI, options pages, permissions, host permissions, JavaScript, or HTML.

## Source Files

Place the extracted Firefox built-in theme files here:

```text
source/alpenglow/
```

The dark build requires these files:

```text
background-gradient-dark.svg
background-noodles-left-dark.svg
background-noodles-right-dark.svg
```

The icon is generated from `icon.svg` when available, with `preview.svg` as a fallback. Light SVG files are not used for the dark theme build.

## Build Assets

From the project root, run:

```sh
python3 firefox-alpenglow-dark-chrome/tools/build-assets.py
```

The script checks the source SVGs, renders and composites the dark Firefox layers, writes PNG assets into `firefox-alpenglow-dark-chrome/images/`, validates the manifest image paths and color arrays, and creates:

```text
firefox-alpenglow-dark-chrome/dist/firefox-alpenglow-dark-chrome.zip
```

Rendering uses Python `cairosvg` if installed. If not, it tries `rsvg-convert`, `inkscape`, then a local headless Chrome canvas renderer that preserves SVG alpha transparency. ImageMagick is retained only as a last-resort fallback for SVGs it can render correctly. Quick Look is intentionally not used for the frame assets because it bakes transparent SVG regions over a white preview background. If none are available, install one of:

```text
pip install cairosvg
brew install librsvg
brew install inkscape
brew install imagemagick
```

## Load In Chrome

1. Open `chrome://extensions`
2. Enable Developer mode
3. Click "Load unpacked"
4. Select the `firefox-alpenglow-dark-chrome` directory

To reload after rebuilding, return to `chrome://extensions` and click the reload button on the theme card. If Chrome keeps an older visual cached, remove the theme and load the directory again.

## Package Zip

Run the build script above. The zip file is written to:

```text
firefox-alpenglow-dark-chrome/dist/firefox-alpenglow-dark-chrome.zip
```

The zip root directly contains `manifest.json`, not an extra parent directory, so Chrome can recognize it if unpacked.

## Manifest Notes

The manifest uses conservative Chrome theme fields:

- `theme.images.theme_frame` uses the composited Alpenglow dark frame PNG.
- `theme.images.theme_frame_inactive` reuses the frame image to reduce Chrome's inactive-window whitening.
- `theme.images.theme_toolbar` is a small selected-tab purple toolbar PNG.
- `theme.images.theme_ntp_background` is a large quiet dark purple gradient for new tab readability and is set to no-repeat to avoid visible tiling.
- `theme.colors.frame`, `toolbar`, `tab_text`, `tab_background_text`, `bookmark_text`, `ntp_background`, `ntp_text`, and `button_background` are migrated to RGB arrays.
- `frame_inactive`, `toolbar_button_icon`, `ntp_link`, and `ntp_section` provide compatible dark/accent approximations.

## Known Limits

- Firefox `additional_backgrounds` layers are adapted into one `theme_frame.png` because Chrome themes do not support Firefox's exact layered theme structure. The Firefox right-aligned frame noodle is intentionally omitted from the Chrome frame output because Chrome cannot anchor it to the window's right edge; a fixed-position copy looks wrong at different window widths.
- Chrome themes do not support all Firefox WebExtension theme color fields.
- Firefox alpha/HSLA values are converted to opaque RGB approximations.
- The result is not guaranteed to be pixel-identical to native Firefox Alpenglow Dark.
- Firefox-only or unsupported fields are omitted, including `popup`, `popup_text`, `popup_border`, `popup_highlight`, `popup_highlight_text`, `sidebar`, `sidebar_text`, `sidebar_border`, `sidebar_highlight`, `sidebar_highlight_text`, `focus_outline`, `theme_experiment`, `toolbar_field_focus`, `toolbar_field_border_focus`, `toolbar_field_highlight`, `toolbar_top_separator`, `toolbar_bottom_separator`, `tab_line`, `tab_loading`, and `zap_gradient`.
