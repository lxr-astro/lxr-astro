#!/usr/bin/env python3
"""Build Chrome theme assets for Firefox Alpenglow Light."""

from __future__ import annotations

import importlib.util
import json
import math
import base64
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
import zipfile
from pathlib import Path
from xml.etree import ElementTree

from PIL import Image
from websocket import create_connection


ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT.parent
SOURCE = PROJECT / "source" / "alpenglow"
IMAGES = ROOT / "images"
DIST = ROOT / "dist"
TARGET_W = 4000
TARGET_H = 200

REQUIRED_SVGS = {
    "gradient": "background-gradient.svg",
    "left": "background-noodles-left.svg",
    "right": "background-noodles-right.svg",
}


def fail(message: str) -> None:
    print(f"ERROR: {message}", file=sys.stderr)
    sys.exit(1)


def svg_size(path: Path) -> tuple[int, int]:
    root = ElementTree.parse(path).getroot()
    width = root.attrib.get("width")
    height = root.attrib.get("height")
    if not width or not height:
        view_box = root.attrib.get("viewBox")
        if not view_box:
            fail(f"{path} has no width/height or viewBox")
        _, _, width, height = view_box.split()
    return int(float(width.rstrip("px"))), int(float(height.rstrip("px")))


def run(cmd: list[str]) -> None:
    try:
        subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except subprocess.CalledProcessError as exc:
        stderr = exc.stderr.decode("utf-8", errors="replace").strip()
        fail(f"Command failed: {' '.join(cmd)}\n{stderr}")


def try_run(cmd: list[str]) -> tuple[bool, str]:
    try:
        subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return True, ""
    except subprocess.CalledProcessError as exc:
        stderr = exc.stderr.decode("utf-8", errors="replace").strip()
        return False, stderr


def render_with_cairosvg(svg: Path, png: Path, width: int, height: int) -> bool:
    if not importlib.util.find_spec("cairosvg"):
        return False
    import cairosvg  # type: ignore

    cairosvg.svg2png(
        url=str(svg),
        write_to=str(png),
        output_width=width,
        output_height=height,
    )
    return True


def render_with_command(svg: Path, png: Path, width: int, height: int) -> bool:
    if shutil.which("rsvg-convert"):
        ok, stderr = try_run(["rsvg-convert", "-w", str(width), "-h", str(height), "-o", str(png), str(svg)])
        if ok:
            return True
        print(f"WARNING: rsvg-convert failed for {svg.name}: {stderr}", file=sys.stderr)
    if shutil.which("inkscape"):
        ok, stderr = try_run(
            [
                "inkscape",
                str(svg),
                "--export-type=png",
                f"--export-filename={png}",
                f"--export-width={width}",
                f"--export-height={height}",
            ]
        )
        if ok:
            return True
        print(f"WARNING: Inkscape failed for {svg.name}: {stderr}", file=sys.stderr)
    if render_with_chrome(svg, png, width, height):
        return True
    if shutil.which("magick"):
        ok, stderr = try_run(
            [
                "magick",
                "-background",
                "none",
                "-density",
                "384",
                str(svg),
                "-resize",
                f"{width}x{height}!",
                str(png),
            ]
        )
        if ok:
            return True
        print(f"WARNING: ImageMagick failed for {svg.name}: {stderr}", file=sys.stderr)
    return False


def chrome_binary() -> str | None:
    candidates = [
        shutil.which("google-chrome"),
        shutil.which("chromium"),
        shutil.which("chrome"),
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        "/Applications/Chromium.app/Contents/MacOS/Chromium",
        "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    ]
    for candidate in candidates:
        if candidate and Path(candidate).exists():
            return str(candidate)
    return None


def free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


class CdpPage:
    def __init__(self, ws_url: str):
        self.ws = create_connection(ws_url, timeout=10)
        self.next_id = 0

    def close(self) -> None:
        self.ws.close()

    def call(self, method: str, params: dict | None = None) -> dict:
        self.next_id += 1
        message_id = self.next_id
        self.ws.send(json.dumps({"id": message_id, "method": method, "params": params or {}}))
        while True:
            message = json.loads(self.ws.recv())
            if message.get("id") == message_id:
                if "error" in message:
                    raise RuntimeError(f"CDP {method} failed: {message['error']}")
                return message.get("result", {})


def render_with_chrome(svg: Path, png: Path, width: int, height: int) -> bool:
    binary = chrome_binary()
    if not binary:
        return False

    for attempt in range(1, 4):
        if render_with_chrome_once(binary, svg, png, width, height, attempt):
            return True
        time.sleep(0.5)
    return False


def render_with_chrome_once(binary: str, svg: Path, png: Path, width: int, height: int, attempt: int) -> bool:
    with tempfile.TemporaryDirectory() as tmp_name:
        tmp = Path(tmp_name)
        port = free_port()
        cmd = [
            binary,
            "--headless=new",
            "--no-first-run",
            "--no-default-browser-check",
            "--disable-background-networking",
            "--disable-gpu",
            "--disable-extensions",
            "--hide-scrollbars",
            "--allow-file-access-from-files",
            "--remote-allow-origins=*",
            "--remote-debugging-address=127.0.0.1",
            f"--remote-debugging-port={port}",
            f"--user-data-dir={tmp / 'chrome-profile'}",
            "about:blank",
        ]
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            ws_url = wait_for_chrome_ws(port)
            page = CdpPage(ws_url)
            try:
                data_url = render_svg_to_canvas_data_url(page, svg, width, height)
                data = base64.b64decode(data_url.split(",", 1)[1])
                png.write_bytes(data)
                if transparent_render_is_valid(png):
                    return True
                print(f"WARNING: Chrome produced an empty render for {svg.name}", file=sys.stderr)
                return False
            finally:
                page.close()
        except Exception as exc:
            print(f"WARNING: Chrome SVG renderer attempt {attempt} failed for {svg.name}: {exc}", file=sys.stderr)
            return False
        finally:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()


def wait_for_chrome_ws(port: int) -> str:
    version_url = f"http://127.0.0.1:{port}/json"
    deadline = time.time() + 10
    last_error: Exception | None = None
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(version_url, timeout=1) as response:
                pages = json.loads(response.read().decode("utf-8"))
            for page in pages:
                if page.get("type") == "page" and page.get("webSocketDebuggerUrl"):
                    return str(page["webSocketDebuggerUrl"])
        except Exception as exc:
            last_error = exc
        time.sleep(0.1)
    raise RuntimeError(f"Chrome DevTools endpoint did not become ready: {last_error}")


def render_svg_to_canvas_data_url(page: CdpPage, svg: Path, width: int, height: int) -> str:
    svg_data = base64.b64encode(svg.read_bytes()).decode("ascii")
    source_url = f"data:image/svg+xml;base64,{svg_data}"
    expression = f"""
(async () => {{
  const img = new Image();
  img.src = {json.dumps(source_url)};
  await new Promise((resolve, reject) => {{
    img.onload = resolve;
    img.onerror = () => reject(new Error("Could not load SVG image"));
    if (img.complete && img.naturalWidth > 0) resolve();
  }});
  const canvas = document.createElement("canvas");
  canvas.width = {width};
  canvas.height = {height};
  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL("image/png");
}})()
"""
    result = page.call(
        "Runtime.evaluate",
        {
            "expression": expression,
            "awaitPromise": True,
            "returnByValue": True,
            "timeout": 10000,
        },
    )
    value = result.get("result", {}).get("value")
    if not isinstance(value, str) or not value.startswith("data:image/png;base64,"):
        raise RuntimeError("Chrome canvas did not return a PNG data URL")
    return value


def svg_render_html(svg: Path, width: int, height: int) -> str:
    src = svg.resolve().as_uri()
    return f"""<!doctype html>
<html>
<head>
<meta charset="utf-8">
<style>
html, body {{
  width: {width}px;
  height: {height}px;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background: transparent;
}}
img {{
  display: block;
  width: {width}px;
  height: {height}px;
}}
</style>
</head>
<body><img id="svg" src="{src}"></body>
</html>"""


def wait_for_svg_ready(page: CdpPage) -> None:
    deadline = time.time() + 10
    expression = "document.readyState === 'complete' && document.getElementById('svg')?.complete"
    while time.time() < deadline:
        result = page.call("Runtime.evaluate", {"expression": expression, "returnByValue": True})
        if result.get("result", {}).get("value") is True:
            return
        time.sleep(0.1)
    raise RuntimeError("Timed out waiting for SVG image to load")


def transparent_render_is_valid(path: Path) -> bool:
    with Image.open(path).convert("RGBA") as image:
        return image.size[0] > 0 and image.size[1] > 0 and image.getchannel("A").getbbox() is not None


def render_with_quicklook(svg: Path, png: Path, width: int, height: int) -> bool:
    with tempfile.TemporaryDirectory() as tmp_name:
        tmp = Path(tmp_name)
        size = str(max(width, height) * 4)
        ok, stderr = try_run(["qlmanage", "-t", "-s", size, "-o", str(tmp), str(svg)])
        if not ok:
            print(f"WARNING: Quick Look failed for {svg.name}: {stderr}", file=sys.stderr)
            return False
        thumbs = sorted(tmp.glob("*.png"))
        if not thumbs:
            print(f"WARNING: Quick Look produced no PNG for {svg.name}", file=sys.stderr)
            return False
        image = Image.open(thumbs[0]).convert("RGBA")
        image = key_out_quicklook_white(image)
        alpha_box = image.getchannel("A").getbbox()
        if alpha_box:
            image = image.crop(alpha_box)
        image = image.resize((width, height), Image.Resampling.LANCZOS)
        image.save(png)
        return True


def key_out_quicklook_white(image: Image.Image) -> Image.Image:
    """Quick Look renders transparent SVG regions over white; restore them."""
    pixels = image.load()
    width, height = image.size
    for y in range(height):
        for x in range(width):
            r, g, b, a = pixels[x, y]
            spread = max(r, g, b) - min(r, g, b)
            if a and (r >= 248 and g >= 248 and b >= 248 or min(r, g, b) >= 180 and spread <= 35):
                pixels[x, y] = (255, 255, 255, 0)
    return image


def render_svg(svg: Path, png: Path, width: int, height: int) -> None:
    png.parent.mkdir(parents=True, exist_ok=True)
    try:
        if render_with_cairosvg(svg, png, width, height):
            return
    except Exception as exc:  # pragma: no cover - depends on local renderer
        print(f"WARNING: CairoSVG failed for {svg.name}: {exc}", file=sys.stderr)
    if render_with_command(svg, png, width, height):
        return
    fail(
        "No SVG renderer found. Install one of: cairosvg for Python, "
        "librsvg/rsvg-convert, Inkscape, or Chrome/Chromium for transparent SVG rendering."
    )


def make_frame(paths: dict[str, Path]) -> None:
    with tempfile.TemporaryDirectory() as tmp_name:
        tmp = Path(tmp_name)
        gradient_w, gradient_h = svg_size(paths["gradient"])
        left_w, left_h = svg_size(paths["left"])

        tile_w = max(1, round(gradient_w * TARGET_H / gradient_h))
        left_render_w = max(1, round(left_w * TARGET_H / left_h))

        gradient_png = tmp / "gradient.png"
        left_png = tmp / "left.png"
        render_svg(paths["gradient"], gradient_png, tile_w, TARGET_H)
        render_svg(paths["left"], left_png, left_render_w, TARGET_H)

        frame = Image.new("RGBA", (TARGET_W, TARGET_H), (255, 201, 153, 255))
        tile = Image.open(gradient_png).convert("RGBA")
        for x in range(0, TARGET_W, tile.width):
            frame.alpha_composite(tile, (x, 0))

        left = Image.open(left_png).convert("RGBA")
        frame.alpha_composite(left, (0, 0))
        lift_light_frame_shadows(frame)
        frame.save(IMAGES / "theme_frame.png")


def lift_light_frame_shadows(image: Image.Image) -> None:
    pixels = image.load()
    width, height = image.size
    target = (150, 88, 205)
    for y in range(height):
        for x in range(width):
            r, g, b, a = pixels[x, y]
            if not a:
                continue
            luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b
            if luminance >= 118:
                continue
            strength = min(1.0, (118 - luminance) / 78 + 0.18)
            pixels[x, y] = (
                round(r * (1 - strength) + target[0] * strength),
                round(g * (1 - strength) + target[1] * strength),
                round(b * (1 - strength) + target[2] * strength),
                a,
            )


def make_toolbar() -> None:
    Image.new("RGBA", (16, 16), (255, 250, 245, 255)).save(IMAGES / "theme_toolbar.png")


def make_ntp_background() -> None:
    width, height = 4000, 2400
    stops = [
        (0.00, (150, 88, 205)),
        (0.14, (178, 84, 226)),
        (0.24, (255, 134, 118)),
        (0.32, (255, 201, 153)),
        (0.40, (255, 246, 238)),
        (1.00, (255, 255, 255)),
    ]
    image = Image.new("RGB", (width, height))
    px = image.load()
    for y in range(height):
        t = y / (height - 1)
        for index in range(len(stops) - 1):
            start_t, start_color = stops[index]
            end_t, end_color = stops[index + 1]
            if start_t <= t <= end_t:
                local = (t - start_t) / (end_t - start_t)
                local = local * local * (3 - 2 * local)
                color = tuple(round(start_color[i] * (1 - local) + end_color[i] * local) for i in range(3))
                break
        else:
            color = stops[-1][1]
        for x in range(width):
            px[x, y] = color
    image.save(IMAGES / "theme_ntp_background.png")


def make_icon() -> None:
    icon_svg = SOURCE / "icon.svg"
    output = IMAGES / "icon128.png"
    if icon_svg.exists():
        with tempfile.TemporaryDirectory() as tmp_name:
            tmp_output = Path(tmp_name) / "icon.png"
            try:
                render_svg(icon_svg, tmp_output, 128, 128)
                image = Image.open(tmp_output).convert("RGBA")
                if image.getchannel("A").getbbox():
                    image.save(output)
                    return
                print(f"WARNING: Rendered {icon_svg.name} is transparent; using placeholder icon.", file=sys.stderr)
            except SystemExit:
                raise
            except Exception as exc:
                print(f"WARNING: Could not render {icon_svg.name}: {exc}", file=sys.stderr)

    image = make_placeholder_icon()
    image.save(output)
    print("WARNING: Generated a placeholder icon because no icon SVG could be rendered.")


def make_placeholder_icon() -> Image.Image:
    size = 128
    image = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    pixels = image.load()
    center = (size - 1) / 2
    radius = 56
    stops = [(144, 89, 255), (255, 74, 162), (255, 189, 79)]
    for y in range(size):
        for x in range(size):
            dx = x - center
            dy = y - center
            dist = math.hypot(dx, dy)
            if dist > radius:
                continue
            t = min(1.0, (x + (size - y)) / (size * 2))
            if t < 0.52:
                local = t / 0.52
                color = tuple(round(stops[0][i] * (1 - local) + stops[1][i] * local) for i in range(3))
            else:
                local = (t - 0.52) / 0.48
                color = tuple(round(stops[1][i] * (1 - local) + stops[2][i] * local) for i in range(3))
            edge = min(1.0, max(0.0, radius - dist))
            pixels[x, y] = (*color, round(255 * edge))
    return image


def validate_manifest() -> None:
    manifest_path = ROOT / "manifest.json"
    with manifest_path.open("r", encoding="utf-8") as handle:
        manifest = json.load(handle)

    forbidden = {
        "background",
        "content_scripts",
        "action",
        "permissions",
        "host_permissions",
        "web_accessible_resources",
        "externally_connectable",
        "options_page",
        "side_panel",
    }
    present = sorted(forbidden.intersection(manifest))
    if present:
        fail(f"Manifest contains forbidden extension keys: {', '.join(present)}")
    if manifest.get("manifest_version") != 3:
        fail("manifest_version must be 3")

    theme = manifest.get("theme", {})
    for rel in theme.get("images", {}).values():
        path = ROOT / rel
        if not path.exists():
            fail(f"Manifest image is missing: {rel}")

    colors = theme.get("colors", {})
    for key, value in colors.items():
        if (
            not isinstance(value, list)
            or len(value) != 3
            or not all(isinstance(channel, int) and 0 <= channel <= 255 for channel in value)
        ):
            fail(f"theme.colors.{key} must be an RGB integer array")


def validate_png(path: Path, expected_size: tuple[int, int] | None = None) -> None:
    if not path.exists():
        fail(f"Missing PNG: {path}")
    with Image.open(path) as image:
        if image.format != "PNG":
            fail(f"{path} is not a PNG")
        if expected_size and image.size != expected_size:
            fail(f"{path} has size {image.size}, expected {expected_size}")


def make_zip() -> None:
    DIST.mkdir(parents=True, exist_ok=True)
    output = DIST / "firefox-alpenglow-chrome.zip"
    if output.exists():
        output.unlink()
    include_dirs = ["images"]
    include_files = ["manifest.json", "README.md"]
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for name in include_files:
            path = ROOT / name
            if path.exists():
                zf.write(path, name)
        for dirname in include_dirs:
            for path in sorted((ROOT / dirname).rglob("*")):
                if path.is_file():
                    zf.write(path, path.relative_to(ROOT).as_posix())


def main() -> None:
    if not SOURCE.exists():
        fail(f"Source directory not found: {SOURCE}")
    paths = {key: SOURCE / filename for key, filename in REQUIRED_SVGS.items()}
    missing = [str(path) for path in paths.values() if not path.exists()]
    if missing:
        fail("Missing required light SVG files:\n" + "\n".join(missing))

    IMAGES.mkdir(parents=True, exist_ok=True)
    make_frame(paths)
    make_toolbar()
    make_ntp_background()
    make_icon()

    validate_png(IMAGES / "theme_frame.png", (TARGET_W, TARGET_H))
    validate_png(IMAGES / "theme_toolbar.png", (16, 16))
    validate_png(IMAGES / "theme_ntp_background.png", (4000, 2400))
    validate_png(IMAGES / "icon128.png", (128, 128))
    validate_manifest()
    make_zip()

    print("Built Chrome theme assets:")
    print(f"- {IMAGES / 'theme_frame.png'} ({TARGET_W}x{TARGET_H})")
    print(f"- {IMAGES / 'theme_toolbar.png'} (16x16)")
    print(f"- {IMAGES / 'theme_ntp_background.png'} (4000x2400)")
    print(f"- {IMAGES / 'icon128.png'} (128x128)")
    print(f"- {DIST / 'firefox-alpenglow-chrome.zip'}")


if __name__ == "__main__":
    main()
